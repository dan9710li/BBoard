package bboard;

public class Room {
	private int number;
	private int occupancy;
	
	public Room(int number, int occupancy) {
		this.number = number;
		this.occupancy = occupancy;
	}
	
	public int getNumber() {
		return this.number;
	}
	
	public int getOccupancy() {
		return this.occupancy;
	}
}
