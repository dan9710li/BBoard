package bboard;

import java.util.ArrayList;

public class Professor extends Employee {
	private ArrayList<Course> schedule;
	private long id;
	private String password;
	
	public Professor(String firstName, String lastName, String midInitial, double salary, long id, String password) {
		super(firstName, lastName, midInitial, salary);
		schedule = new ArrayList<Course>();
		this.id = id;
		this.password = password;
	}
	
	public ArrayList<Course> getSchedule() {
		return this.schedule;
	}
	
	public void addCourse(Course course) {
		this.schedule.add(course);
	}
	public long getID() {
		return id;
	}
	public boolean validate(String pass) {
		return password.equals(pass);
	}
}
