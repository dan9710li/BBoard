package bboard;


public class Admin extends Employee {
	private long id;
	private String password;
	
	public Admin(String firstName, String lastName, String midInitial, double salary, long id, String password) {
		super(firstName, lastName, midInitial, salary);
		this.id = id;
		this.password = password;
	}

	public long getID() {
		return id;
	}
	public boolean validate(String pass) {
		return password.equals(pass);
	}
}
