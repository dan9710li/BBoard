package bboard;

import java.util.ArrayList;

public class Student extends Person {
	private ArrayList<Course> schedule;
	private ArrayList<Course> passedCourses;
	private long id;
	private String password;
	
	public Student(String firstName, String lastName, String midInitial, long id, String password) {
		super(firstName, lastName, midInitial);
		schedule = new ArrayList<Course>();
		passedCourses = new ArrayList<Course>();
		this.id = id;
		this.password = password;
	}
	
	public long getID() {
		return id;
	}
	
	public ArrayList<Course> getPassedCourses() {
		return this.passedCourses;
	}
	
	public void addPassedCourse(Course course) {
		this.passedCourses.add(course);
	}
	
	public ArrayList<Course> getSchedule() {
		return this.schedule;
	}
	
	public void addCourse(Course course) {
		this.schedule.add(course);
	}
	
	public int getUnits(){
		int units = 0;
		for(int i = 0; i < schedule.size(); i++) {
			units += schedule.get(i).getUnits();
		}
		return units;
	}
	public boolean validate(String pass) {
		return this.password.equals(pass);
	}
}
