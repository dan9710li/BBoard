package bboard;

import java.util.ArrayList;

public class Session {
	private Professor professor;
	private ArrayList<Student> students;
	private Room room;
	private String startTime;
	private String endTime;
	
	public Session(Professor professor, Room room, String startTime, String endTime){
		this.professor = professor;
		this.room = room;
		this.startTime = startTime;
		this.endTime = endTime;
		
		this.students = new ArrayList<Student>();
	}
	
	public void addStudent(Student student){
		students.add(student);
	}
	
	public Professor getProf(){
		return this.professor;
	}
	
	public ArrayList<Student> getStudents(){
		return this.students;
	}
	
	public Room getRoom(){
		return this.room;
	}
	
	public String getStartTime(){
		return this.startTime;
	}
	
	public String getEndTime(){
		return this.endTime;
	}
}
