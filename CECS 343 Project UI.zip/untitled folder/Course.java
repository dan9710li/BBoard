package bboard;

import java.util.ArrayList;

public class Course {
	private String name;
	private ArrayList<Session> sessions;
	private ArrayList<Course> prereqs;
	private int units;
	
	public Course(String name, int units) {
		this.name = name;
		this.units = units;
		
		this.sessions = new ArrayList<Session>();
		this.prereqs = new ArrayList<Course>();
	}
	
	public String getName() {
		return this.name;
	}
	
	public ArrayList<Session> getSessions() {
		return this.sessions;
	}
	
	public ArrayList<Course> getPreReqs() {
		return this.prereqs;
	}
	
	public int getUnits() {
		return this.units;
	}
	
	public void addPreReq(Course prereq) {
		this.prereqs.add(prereq);
	}
}
