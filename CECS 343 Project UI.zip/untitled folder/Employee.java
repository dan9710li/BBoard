package bboard;

public class Employee extends Person {
	private double salary;

	public Employee(String firstName, String lastName, String midInitial, double salary) {
		super(firstName, lastName, midInitial);
		this.salary = salary;
	}
	
	public double getSalary() {
		return this.salary;
	}
}