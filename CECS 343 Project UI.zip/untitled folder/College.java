package bboard;

import java.util.ArrayList;

public class College {
	private String name;
	private Employee dean;
	private ArrayList<Department> departments;
	private Room office;
	private String schoolTele;
	
	public College(String name, Employee dean, Room office, String schoolTele){
		this.name = name;
		this.dean = dean;
		this.office = office;
		this.schoolTele = schoolTele;
		
		this.departments = new ArrayList<Department>();
	}
	
	public void addDep(Department department){
		departments.add(department);
	}
	
	public String getName(){
		return this.name;
	}
	
	public String getTelephone(){
		return this.schoolTele;
	}
	
	public Employee getDean(){
		return this.dean;
	}
	
	public Room getOffice(){
		return this.office;
	}
	
	public ArrayList<Department> getDepartments(){
		return this.departments;
	}
}
