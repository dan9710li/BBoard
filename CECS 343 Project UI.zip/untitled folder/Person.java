package bboard;

public class Person {
	private String firstName;
	private String lastName;
	private String midInitial;
	private Address address;
	
	public Person(String firstName, String lastName, String midInitial) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.midInitial = midInitial;
	}
	
	public Person() {
		this.firstName = "N/a";
		this.lastName = "N/a";
		this.midInitial = "N/a";
	} 
	public String getfName() {
		return firstName;
	}
	public String getlName() {
		return lastName;
	}
}
