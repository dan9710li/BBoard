package bboard;

import java.util.ArrayList;

public class Building {
	private String name;
	private ArrayList<Room> rooms;
	
	public Building(String name) {
		this.name = name;
		this.rooms = new ArrayList<Room>();
	}
	
	public String getName() {
		return this.name;
	}
	
	public ArrayList<Room> getRooms() {
		return this.rooms;
	}
}
