package bboard;

import java.util.ArrayList;

public class Department {
	private String name;
	private Employee chair;
	private Room office;
	private String schoolTele;
	private Employee undergradAdvisor;
	private ArrayList<Course> courses;
	
	public Department(String name, Employee chair, Room office, String schoolTele, Employee undergradAdvisor){
		this.name = name;
		this.chair = chair;
		this.office = office;
		this.schoolTele = schoolTele;
		this.undergradAdvisor = undergradAdvisor;
		
		this.courses = new ArrayList<Course>();
	}
	
	public void addCourse(Course course){
		courses.add(course);
	}
	
	public String getName(){
		return this.name;
	}
	
	public Employee getChair(){
		return this.chair;
	}
	
	public Room getOffice(){
		return this.office;
	}
	
	public String getPhone(){
		return this.schoolTele;
	}
	
	public Employee getUndergradAdvisor(){
		return this.undergradAdvisor;
	}
	
	public ArrayList<Course> getCourses(){
		return this.courses;
	}
}