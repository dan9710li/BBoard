package bboard;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JList;
import javax.swing.JComboBox;

public class Main {
	private String uniName = "Cal state Long Beach";
	private ArrayList<Student> students;
	private ArrayList<Professor> professors;
	private ArrayList<Admin> admins;
	private ArrayList<College> colleges;
	private ArrayList<Employee> employees;
	private ArrayList<Room> rooms;
	private ArrayList<Department> departments;
	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JLabel lblPass;
	private JLabel lblLogin;
	private JButton btnBack;
	private JPanel panelAdmin;
	private JLabel lblWelcomeAdmin;
	private JPanel panelStudent;
	private JPanel panelProfessor;
	private JPanel panelAdminUniversity;
	private JPanel panelAdminMenu;
	private JButton btnUniversity;
	private JButton btnEmployees;
	private JButton btnStudents;
	private JPanel panelAdminEmployees;
	private JPanel panelAdminStudents;
	private JButton btnAdminBack;
	private JLabel lblUniversityName;
	private JButton btnColleges;
	private JButton btnDepartments;
	private JList listCollege_dept;
	private JList listDept;
	private JButton btnSelect;
	private JButton btnEdit;
	private JButton btnRemove;
	private JButton btnAddCollege;
	private JPanel panelAddCollege;
	private JTextField addCollegeName;
	private JLabel lblName;
	private JTextField addCollegePhone;
	private JLabel lblPhone;
	private JButton btnChange;
	private JPanel panelChangeName;
	private JTextField uniTextChange;
	private JButton btnChangeUniName;
	private JLabel lblUniName;
	private JButton btnCourses;
	private JPanel panelCourses;
	private JList list;
	private JList list_1;
	private JButton btnCoursesSelect;
	private JButton btnCourseEdit;
	private JButton btnCourseRemove;
	private JButton btnAddCourse;
	private JLabel lblCourses;
	private JLabel lblSessions;
	private JList list_2;
	private JButton btnAddStudents;
	private JButton btnEditStudents;
	private JButton btnRemoveStudents;
	private JLabel lblStudents;
	private JList list_3;
	private JLabel lblEmployees;
	private JButton btnAddEmployee;
	private JButton btnEditEmployee;
	private JButton btnRemoveEmployee;
	private JList list_4;
	private JList list_5;
	private JLabel lblSchedule;
	private JLabel lblCourses_1;
	private JButton btnSelectStudentCourses;
	private JButton btnAddStudentCourses;
	private JButton btnDropCourse;
	private JList list_7;
	private JLabel lblCourses_2;
	private JLabel lblSchedule_1;
	private JLabel lblWelcomeProfessors;
	private JButton btnSelectProfessor;
	private JButton btnAddProfessor;
	private JButton btnDropProfessor;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main window = new Main();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Main() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		DefaultListModel listModelColleges = new DefaultListModel();
		DefaultListModel listModelDept = new DefaultListModel();
		students = new  ArrayList<Student>();
		students.add(new Student("Sukrit","Mehra","SM",100,"test"));
		students.add(new Student("Daniel","Li","A", 101, "test1"));
		students.add(new Student("Aish","Ravishankar","", 103, "test2"));
		students.add(new Student("Dhiren", "Lalwani", "C", 104, "test"));
		
		professors = new ArrayList<Professor>();
		professors.add(new Professor("David", "Brown", "D", 19000.00, 10, "test"));
		professors.add(new Professor("Dave", "Winters", "A", 2000.00, 11, "test1"));
		professors.add(new Professor("Phuong", "Nguyen", "F", 3000.00, 12, "test2"));
		
		admins = new ArrayList<Admin>();
		admins.add(new Admin("Admin", "One", "", 19000.00, 01, "test"));
		admins.add(new Admin("Admin", "Two", "", 2000.00, 02, "test1"));
		admins.add(new Admin("Admin", "Three", "", 3000.00, 03, "test2"));
		
		employees = new ArrayList<Employee>();
		employees.add(new Employee("Alvaro", "Monge", "N", 19000.00));
		employees.add(new Employee("Benjamin", "Denver", "A", 2000.00));
		employees.add(new Employee("Adam", "Silver", "F", 3000.00));
		
		rooms = new ArrayList<Room>();
		rooms.add(new Room(100, 50));
		rooms.add(new Room(101, 50));
		rooms.add(new Room(102, 50));
		
		colleges = new ArrayList<College>();
		colleges.add(new College("College of Engineering",employees.get(0) , rooms.get(0), "562-985-5294"));
		
		departments = new ArrayList<Department>();
		departments.add(new Department("Computer Science",employees.get(1), rooms.get(1), "562-985-7843", employees.get(2)));
		colleges.get(0).addDep(departments.get(0));
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		
		panelProfessor = new JPanel();
		panelProfessor.setBounds(6, 6, 438, 266);
		frame.getContentPane().add(panelProfessor);
		panelProfessor.setLayout(null);
		
		JList list_6 = new JList();
		list_6.setBounds(32, 59, 190, 105);
		panelProfessor.add(list_6);
		
		list_7 = new JList();
		list_7.setBounds(232, 57, 184, 107);
		panelProfessor.add(list_7);
		
		lblCourses_2 = new JLabel("Courses");
		lblCourses_2.setBounds(275, 33, 61, 16);
		panelProfessor.add(lblCourses_2);
		
		lblSchedule_1 = new JLabel("Schedule");
		lblSchedule_1.setBounds(87, 33, 61, 16);
		panelProfessor.add(lblSchedule_1);
		
		lblWelcomeProfessors = new JLabel("Welcome Professors");
		lblWelcomeProfessors.setBounds(146, 6, 190, 16);
		panelProfessor.add(lblWelcomeProfessors);
		
		btnSelectProfessor = new JButton("Select");
		btnSelectProfessor.setBounds(31, 169, 117, 29);
		panelProfessor.add(btnSelectProfessor);
		
		btnAddProfessor = new JButton("Add");
		btnAddProfessor.setEnabled(false);
		btnAddProfessor.setBounds(157, 176, 117, 29);
		panelProfessor.add(btnAddProfessor);
		
		btnDropProfessor = new JButton("Drop");
		btnDropProfessor.setEnabled(false);
		btnDropProfessor.setBounds(286, 169, 117, 29);
		panelProfessor.add(btnDropProfessor);
		panelProfessor.setVisible(false);
		
		panelStudent = new JPanel();
		panelStudent.setBounds(6, 6, 438, 266);
		frame.getContentPane().add(panelStudent);
		panelStudent.setLayout(null);
		
		list_4 = new JList();
		list_4.setBounds(33, 45, 172, 124);
		panelStudent.add(list_4);
		
		list_5 = new JList();
		list_5.setBounds(234, 45, 172, 124);
		panelStudent.add(list_5);
		
		lblSchedule = new JLabel("Schedule");
		lblSchedule.setBounds(83, 26, 61, 16);
		panelStudent.add(lblSchedule);
		
		lblCourses_1 = new JLabel("Courses");
		lblCourses_1.setBounds(274, 26, 61, 16);
		panelStudent.add(lblCourses_1);
		
		btnSelectStudentCourses = new JButton("Select");
		btnSelectStudentCourses.setBounds(27, 181, 117, 29);
		panelStudent.add(btnSelectStudentCourses);
		
		btnAddStudentCourses = new JButton("Add");
		btnAddStudentCourses.setEnabled(false);
		btnAddStudentCourses.setBounds(150, 181, 117, 29);
		panelStudent.add(btnAddStudentCourses);
		
		btnDropCourse = new JButton("Drop");
		btnDropCourse.setEnabled(false);
		btnDropCourse.setBounds(278, 181, 117, 29);
		panelStudent.add(btnDropCourse);
		panelStudent.setVisible(false);
		
		panelAdmin = new JPanel();
		panelAdmin.setBounds(6, 6, 438, 266);
		frame.getContentPane().add(panelAdmin);
		panelAdmin.setLayout(null);
		panelAdmin.setVisible(false);
		
		panelAddCollege = new JPanel();
		panelAddCollege.setBounds(6, 24, 426, 236);
		panelAdmin.add(panelAddCollege);
		panelAddCollege.setLayout(null);
		panelAddCollege.setVisible(false);
		
		addCollegeName = new JTextField();
		addCollegeName.setBounds(136, 18, 130, 26);
		panelAddCollege.add(addCollegeName);
		addCollegeName.setColumns(10);
		addCollegeName.setVisible(false);
		
		lblName = new JLabel("Name");
		lblName.setBounds(37, 23, 61, 16);
		panelAddCollege.add(lblName);
		lblName.setVisible(false);
		
		addCollegePhone = new JTextField();
		addCollegePhone.setBounds(136, 158, 130, 26);
		panelAddCollege.add(addCollegePhone);
		addCollegePhone.setColumns(10);
		addCollegePhone.setVisible(false);
		
		lblPhone = new JLabel("Phone");
		lblPhone.setBounds(37, 163, 61, 16);
		panelAddCollege.add(lblPhone);
		lblPhone.setVisible(false);
		
		JComboBox AddCollegeEmployee = new JComboBox();
		AddCollegeEmployee.setBounds(136, 63, 180, 42);
		panelAddCollege.add(AddCollegeEmployee);
		AddCollegeEmployee.setVisible(false);
		
		JComboBox AddCollegeRoom = new JComboBox();
		AddCollegeRoom.setBounds(136, 107, 180, 39);
		panelAddCollege.add(AddCollegeRoom);
		AddCollegeRoom.setVisible(false);
		
		JLabel lblDean = new JLabel("Dean");
		lblDean.setBounds(37, 70, 61, 16);
		panelAddCollege.add(lblDean);
		lblDean.setVisible(false);
		
		JLabel lblRoom = new JLabel("Room");
		lblRoom.setBounds(37, 111, 61, 16);
		panelAddCollege.add(lblRoom);
		lblRoom.setVisible(false);
		
		JButton btnAddcollege = new JButton("AddCollege");
		
		btnAddcollege.setBounds(136, 196, 117, 29);
		panelAddCollege.add(btnAddcollege);
		btnAddcollege.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				lblName.setVisible(true);
				lblPhone.setVisible(true);
				lblDean.setVisible(true);
				lblRoom.setVisible(true);
				Employee em = null;
				Room rm = null;
				String name = addCollegeName.getText();
				String Emp = AddCollegeEmployee.getSelectedItem().toString();
				for(Employee i:employees) {
					if(i.getfName().equals(Emp))
						em = i;
				}
				String room = AddCollegeRoom.getSelectedItem().toString();
				for(Room i: rooms) {
					if(i.getNumber() == Integer.parseInt(room))
						rm = i;
				}
				if(em == null ||rm == null)
					JOptionPane.showMessageDialog(null, "Error cannot have empty fields");
				else {
				String Phone = addCollegePhone.getText();
				College temp = new College(name,em,rm,Phone);
				addCollegeName.setText("");
				AddCollegeRoom.removeAllItems();
				AddCollegeEmployee.removeAllItems();
				addCollegePhone.setText("");
				panelAddCollege.setVisible(false);
				panelAdminUniversity.setVisible(true);
				colleges.add(temp);
				listModelColleges.clear();
				
				for(College i:colleges) {
					listModelColleges.addElement(i.getName());
				}
				if(colleges.size()<10) {
					btnAddCollege.setEnabled(true);
				}
				else
					btnAddCollege.setEnabled(false);
				}
				//System.out.println(name+Employee+room+Phone);
			}
		});
		
		
		panelAdminMenu = new JPanel();
		panelAdminMenu.setBounds(6, 22, 426, 238);
		panelAdmin.add(panelAdminMenu);
		panelAdminMenu.setLayout(null);
		panelAdminMenu.setVisible(false);
		
		btnUniversity = new JButton("University");
		
		btnUniversity.setBounds(27, 40, 107, 29);
		panelAdminMenu.add(btnUniversity);
		
		btnEmployees = new JButton("Employees");
		
		btnEmployees.setBounds(261, 40, 111, 29);
		panelAdminMenu.add(btnEmployees);
		
		btnStudents = new JButton("Students");
		
		btnStudents.setBounds(27, 117, 99, 29);
		panelAdminMenu.add(btnStudents);
		
		btnCourses = new JButton("Courses");
		btnCourses.setVisible(true);
		
		btnCourses.setBounds(261, 117, 117, 29);
		panelAdminMenu.add(btnCourses);
		
		
		btnUniversity.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				panelAdminMenu.setVisible(false);
				panelAdminUniversity.setVisible(true);
				btnAdminBack.setVisible(true);
			}
		});
		btnEmployees.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				panelAdminMenu.setVisible(false);
				panelAdminEmployees.setVisible(true);
				btnAdminBack.setVisible(true);
			}
		});
		btnStudents.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				panelAdminMenu.setVisible(false);
				panelAdminStudents.setVisible(true);
				btnAdminBack.setVisible(true);
			}
		});
		btnCourses.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				panelAdminMenu.setVisible(false);
				btnAdminBack.setVisible(true);
				panelCourses.setVisible(true);
			}
		});
		
		panelAdminEmployees = new JPanel();
		panelAdminEmployees.setBounds(6, 22, 426, 238);
		panelAdmin.add(panelAdminEmployees);
		panelAdminEmployees.setLayout(null);
		
		list_3 = new JList();
		list_3.setBounds(27, 48, 358, 100);
		panelAdminEmployees.add(list_3);
		
		lblEmployees = new JLabel("Employees");
		lblEmployees.setBounds(162, 20, 77, 16);
		panelAdminEmployees.add(lblEmployees);
		
		btnAddEmployee = new JButton("Add");
		btnAddEmployee.setBounds(27, 160, 117, 29);
		panelAdminEmployees.add(btnAddEmployee);
		
		btnEditEmployee = new JButton("Edit");
		btnEditEmployee.setEnabled(false);
		btnEditEmployee.setBounds(153, 160, 117, 29);
		panelAdminEmployees.add(btnEditEmployee);
		
		btnRemoveEmployee = new JButton("Remove");
		btnRemoveEmployee.setEnabled(false);
		btnRemoveEmployee.setBounds(268, 160, 117, 29);
		panelAdminEmployees.add(btnRemoveEmployee);
		
		panelAdminStudents = new JPanel();
		panelAdminStudents.setBounds(6, 22, 426, 238);
		panelAdmin.add(panelAdminStudents);
		panelAdminStudents.setLayout(null);
		
		lblStudents = new JLabel("Students");
		lblStudents.setBounds(167, 26, 61, 16);
		panelAdminStudents.add(lblStudents);
		
		btnRemoveStudents = new JButton("Remove");
		btnRemoveStudents.setBounds(150, 158, 117, 29);
		panelAdminStudents.add(btnRemoveStudents);
		btnRemoveStudents.setEnabled(false);
		
		btnEditStudents = new JButton("Edit");
		btnEditStudents.setBounds(264, 159, 117, 29);
		panelAdminStudents.add(btnEditStudents);
		btnEditStudents.setEnabled(false);
		
		btnAddStudents = new JButton("Add");
		btnAddStudents.setBounds(27, 157, 117, 29);
		panelAdminStudents.add(btnAddStudents);
		
		list_2 = new JList();
		list_2.setBounds(33, 45, 362, 106);
		panelAdminStudents.add(list_2);
		
		panelCourses = new JPanel();
		panelCourses.setBounds(6, 22, 426, 238);
		panelAdmin.add(panelCourses);
		panelCourses.setLayout(null);
		panelCourses.setVisible(false);
		
		list = new JList();
		list.setBounds(30, 44, 178, 86);
		panelCourses.add(list);
		
		list_1 = new JList();
		list_1.setBounds(220, 44, 171, 86);
		panelCourses.add(list_1);
		
		btnCoursesSelect = new JButton("Select");
		btnCoursesSelect.setEnabled(false);
		btnCoursesSelect.setBounds(25, 142, 117, 29);
		panelCourses.add(btnCoursesSelect);
		
		btnCourseEdit = new JButton("Edit");
		btnCourseEdit.setEnabled(false);
		btnCourseEdit.setBounds(274, 142, 117, 29);
		panelCourses.add(btnCourseEdit);
		
		btnCourseRemove = new JButton("Remove");
		btnCourseRemove.setBounds(145, 142, 117, 29);
		panelCourses.add(btnCourseRemove);
		
		btnAddCourse = new JButton("Add");
		btnAddCourse.setBounds(145, 183, 117, 29);
		panelCourses.add(btnAddCourse);
		
		lblCourses = new JLabel("Courses");
		lblCourses.setBounds(47, 16, 61, 16);
		panelCourses.add(lblCourses);
		
		lblSessions = new JLabel("Sessions");
		lblSessions.setBounds(274, 16, 61, 16);
		panelCourses.add(lblSessions);
		
		panelChangeName = new JPanel();
		panelChangeName.setBounds(6, 24, 426, 236);
		panelAdmin.add(panelChangeName);
		panelChangeName.setLayout(null);
		panelChangeName.setVisible(false);
		
		uniTextChange = new JTextField();
		uniTextChange.setBounds(90, 66, 238, 26);
		panelChangeName.add(uniTextChange);
		uniTextChange.setColumns(10);
		uniTextChange.setVisible(false);
		
		btnChangeUniName = new JButton("Change Name");
		
		btnChangeUniName.setBounds(135, 104, 117, 29);
		panelChangeName.add(btnChangeUniName);
		
		lblUniName = new JLabel("Uni Name");
		lblUniName.setBounds(159, 50, 61, 16);
		lblUniName.setVisible(false);
		panelChangeName.add(lblUniName);
		btnChangeUniName.setVisible(false);
		
		panelAdminUniversity = new JPanel();
		panelAdminUniversity.setBounds(6, 24, 426, 236);
		panelAdmin.add(panelAdminUniversity);
		panelAdminUniversity.setLayout(null);
		
		lblUniversityName = new JLabel(uniName);
		lblUniversityName.setBounds(118, 6, 157, 16);
		panelAdminUniversity.add(lblUniversityName);
		
		btnColleges = new JButton("Colleges");
		
		btnColleges.setBounds(28, 137, 117, 29);
		panelAdminUniversity.add(btnColleges);
		
		btnDepartments = new JButton("Departments");
		
		btnDepartments.setBounds(243, 137, 117, 29);
		panelAdminUniversity.add(btnDepartments);
		JList listColleges = new JList(listModelColleges);
		
		listColleges.setBounds(41, 36, 322, 99);
		panelAdminUniversity.add(listColleges);
		
		listCollege_dept = new JList(listModelColleges);
		
		listCollege_dept.setBounds(39, 36, 165, 99);
		panelAdminUniversity.add(listCollege_dept);
		
		listDept = new JList(listModelDept);
		listDept.setBounds(203, 34, 165, 104);
		panelAdminUniversity.add(listDept);
		listDept.setVisible(false);
		
		btnSelect = new JButton("Select");
		
		btnSelect.setEnabled(false);
		btnSelect.setBounds(28, 165, 117, 29);
		panelAdminUniversity.add(btnSelect);
		btnSelect.setVisible(false);
		
		btnEdit = new JButton("Edit");
		btnEdit.setEnabled(false);
		btnEdit.setBounds(243, 165, 117, 29);
		panelAdminUniversity.add(btnEdit);
		
		btnRemove = new JButton("Remove");
		
		btnRemove.setEnabled(false);
		btnRemove.setBounds(138, 165, 117, 29);
		panelAdminUniversity.add(btnRemove);
		
		btnAddCollege = new JButton("Add");
		
		btnAddCollege.setEnabled(false);
		btnAddCollege.setBounds(28, 165, 117, 29);
		panelAdminUniversity.add(btnAddCollege);
		
		btnChange = new JButton("Change");
		
		btnChange.setBounds(269, 1, 91, 29);
		panelAdminUniversity.add(btnChange);
		btnAddCollege.setVisible(false);
		btnRemove.setVisible(false);
		btnEdit.setVisible(false);
		listCollege_dept.setVisible(false);
		listColleges.setVisible(false);
		panelAdminUniversity.setVisible(false);
		btnColleges.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				listColleges.setVisible(true);
				listCollege_dept.setVisible(false);
				listDept.setVisible(false);
				//btnDepartments.setVisible(false);
				btnEdit.setVisible(true);
				btnEdit.setEnabled(false);
				btnSelect.setVisible(false);
				btnRemove.setVisible(true);
				btnRemove.setEnabled(false);
				btnAddCollege.setVisible(true);
				if(colleges.size()<10)
					btnAddCollege.setEnabled(true);
				else
					btnAddCollege.setEnabled(false);
				listModelColleges.clear();
				for(College i:colleges) {
					listModelColleges.addElement(i.getName());
				}
			}
		});
		
		listColleges.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				btnEdit.setEnabled(true);
				btnRemove.setEnabled(true);
			}
		});
		
		btnRemove.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String selected = listColleges.getSelectedValue().toString();
				System.out.println(selected);
				for(College i: colleges) {
					if(i.getName().equals(selected)) {
						colleges.remove(colleges.indexOf(i));
						break;
					}
				}
				listModelColleges.clear();
				for(College i:colleges) {
					listModelColleges.addElement(i.getName());
				}
				if(colleges.size()<10) {
					btnAddCollege.setEnabled(true);
				}
				else
					btnAddCollege.setEnabled(false);
			}
		});
		
		lblWelcomeAdmin = new JLabel("Welcome Admin");
		lblWelcomeAdmin.setBounds(153, 6, 138, 16);
		panelAdmin.add(lblWelcomeAdmin);
		
		btnAdminBack = new JButton("Back");
		btnAdminBack.setBounds(315, 1, 75, 29);
		panelAdmin.add(btnAdminBack);
		btnAdminBack.setVisible(false);
		btnAdminBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				panelAdminUniversity.setVisible(false);
				panelAdminEmployees.setVisible(false);
				panelAdminStudents.setVisible(false);
				panelAdminMenu.setVisible(true);

				btnAdminBack.setVisible(false);
				AddCollegeEmployee.setVisible(false);
				AddCollegeRoom.setVisible(false);
				addCollegePhone.setVisible(false);
				addCollegeName.setVisible(false);
				panelAddCollege.setVisible(false);
				lblName.setVisible(false);
				lblPhone.setVisible(false);
				lblDean.setVisible(false);
				lblRoom.setVisible(false);
				uniTextChange.setVisible(false);
				btnChangeUniName.setVisible(false);
				panelChangeName.setVisible(false);
				lblUniName.setVisible(false);
				panelCourses.setVisible(false);
			}
		});
		btnAddCollege.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//panelAddCollege.setVisible(true);
				lblName.setVisible(true);
				lblPhone.setVisible(true);
				lblDean.setVisible(true);
				lblRoom.setVisible(true);
				panelAdminUniversity.setVisible(false);
				panelAddCollege.setVisible(true);
				AddCollegeEmployee.setVisible(true);
				AddCollegeRoom.setVisible(true);
				addCollegePhone.setVisible(true);
				addCollegeName.setVisible(true);
				AddCollegeEmployee.removeAllItems();
				AddCollegeRoom.removeAllItems();
				
				for(Room i:rooms) {
					AddCollegeRoom.addItem(i.getNumber());
				}
				for(Employee i:employees) {
					AddCollegeEmployee.addItem(i.getfName());
				}
			}
		});
		btnDepartments.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				listModelDept.clear();
				listModelColleges.clear();
				for(College i:colleges) {
					listModelColleges.addElement(i.getName());
				}
				listColleges.setVisible(false);
				listCollege_dept.setVisible(true);
				listDept.setVisible(true);
				//btnDepartments.setVisible(false);
				btnEdit.setVisible(true);
				btnEdit.setEnabled(false);
				btnSelect.setVisible(true);
				btnSelect.setEnabled(false);
				btnRemove.setVisible(false);
				btnRemove.setEnabled(false);
				btnAddCollege.setVisible(false);
			}
		});
		
		listCollege_dept.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				btnSelect.setVisible(true);
				btnSelect.setEnabled(true);
			}
		});
		
		btnSelect.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String selected = listCollege_dept.getSelectedValue().toString();
				System.out.println(selected);
				College test=null;
				listModelDept.clear();
				for(College i:colleges) {
					if(i.getName().equals(selected)) {
						test = i;
					}
					
				}
				ArrayList<Department> x = test.getDepartments();
				for(Department y: x) {
					listModelDept.addElement(y.getName());
					System.out.println(y.getName());
				}
				//listDept.;
				
			}
		});
		
		btnChange.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				uniTextChange.setText(uniName);
				lblUniName.setVisible(true);
				uniTextChange.setVisible(true);
				btnChangeUniName.setVisible(true);
				panelChangeName.setVisible(true);
				panelAdminUniversity.setVisible(false);
				
			}
		});
		
		btnChangeUniName.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				uniName = uniTextChange.getText();
				lblUniversityName.setText(uniName);
				lblUniName.setVisible(false);
				uniTextChange.setVisible(false);
				btnChangeUniName.setVisible(false);
				panelChangeName.setVisible(false);
				panelAdminUniversity.setVisible(true);
			}
		});
		
		JPanel panelLogin = new JPanel();
		panelLogin.setBounds(6, 6, 438, 266);
		frame.getContentPane().add(panelLogin);
		panelLogin.setLayout(null);
		panelLogin.setVisible(true);
		
		
		
		JButton btnLogin = new JButton("Login");
		
		btnLogin.setBounds(166, 189, 79, 29);
		panelLogin.add(btnLogin);
		
		JLabel lblId = new JLabel("ID");
		lblId.setBounds(85, 103, 29, 16);
		panelLogin.add(lblId);
		
		lblPass = new JLabel("pass");
		lblPass.setBounds(80, 168, 58, 16);
		panelLogin.add(lblPass);
		
		JButton btnHello = new JButton("Admin");
		btnHello.setBounds(90, 57, 85, 29);
		panelLogin.add(btnHello);
		
		JButton btnNewButton = new JButton("Student");
		btnNewButton.setBounds(208, 57, 92, 29);
		panelLogin.add(btnNewButton);
		
		textField = new JTextField();
		textField.setBounds(136, 98, 130, 26);
		panelLogin.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(136, 163, 130, 26);
		panelLogin.add(textField_1);
		textField_1.setColumns(10);
		textField_1.setVisible(false);
		textField.setVisible(false);
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textField.setVisible(true);
				textField_1.setVisible(true);
				lblLogin.setText("Student Login");
				btnLogin.setVisible(true);
				btnHello.setVisible(false);
				btnNewButton.setVisible(false);
				lblPass.setVisible(true);
				lblId.setVisible(true);
				btnBack.setVisible(true);
			}
		});
		
		btnHello.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textField.setVisible(true);
				textField_1.setVisible(true);
				lblLogin.setText("Admin Login");
				btnLogin.setVisible(true);
				btnHello.setVisible(false);
				btnNewButton.setVisible(false);
				lblPass.setVisible(true);
				lblId.setVisible(true);
				btnBack.setVisible(true);
			}
		});
		lblPass.setVisible(false);
		lblId.setVisible(false);
		btnLogin.setVisible(false);
		
		lblLogin = new JLabel("Login");
		lblLogin.setBounds(164, 29, 123, 16);
		panelLogin.add(lblLogin);
		//frame.getContentPane().add(lblLogin);
		
		btnBack = new JButton("Back");
		
		btnBack.setBounds(166, 230, 75, 29);
		panelLogin.add(btnBack);
		
		
		
		//frame.getContentPane().add(btnBack);
		
		
		btnBack.setVisible(false);
		lblLogin.setVisible(true);
		btnBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textField.setVisible(false);
				textField_1.setVisible(false);
				lblLogin.setText("Login");
				btnLogin.setVisible(false);
				btnHello.setVisible(true);
				btnNewButton.setVisible(true);
				lblPass.setVisible(false);
				lblId.setVisible(false);
				btnBack.setVisible(false);
				
			}
		});
		
		btnLogin.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//check login validity
				Student test = null;
				Professor prof=null;
				Admin admin = null;
				boolean valid = false;
				if(lblLogin.getText().equals("Student Login")){
					
					for(Student i : students) {
						if(i.getID()==Long.parseLong(textField.getText())) {
							valid = i.validate(textField_1.getText());
							if(valid) {
								test = i;
								break;
							}
							
						}
					}
					if(valid) {
						JOptionPane.showMessageDialog(null, "welcome Student");
						panelLogin.setVisible(false);
						panelStudent.setVisible(true);
					}
					else {
						for(Professor i : professors) {
							if(i.getID()==Long.parseLong(textField.getText())) {
								valid = i.validate(textField_1.getText());
								if(valid) {
									prof = i;
									break;
								}
								
							}
						}
						if(valid) {
							JOptionPane.showMessageDialog(null, "welcome Professor");
							panelLogin.setVisible(false);
							panelProfessor.setVisible(true);
						}
						else
							JOptionPane.showMessageDialog(null, "Wrong Id or pass");
					}
				}
				//Admin login
				else {
					for(Admin i : admins) {
						if(i.getID()==Long.parseLong(textField.getText())) {
							valid = i.validate(textField_1.getText());
							if(valid) {
								admin = i;
								break;
							}
							
						}
					}
					if(valid) {
						JOptionPane.showMessageDialog(null, "welcome Admin");
						panelLogin.setVisible(false);
						panelAdmin.setVisible(true);
						panelAdminMenu.setVisible(true);
					}
					else
						JOptionPane.showMessageDialog(null, "Wrong Id or pass");
					
				}
				//if valid
				//panelLogin.setVisible(false);
				//panelAdmin.setVisible(true);
			}
		});
	}	
	}
